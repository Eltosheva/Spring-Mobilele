package softuni.lection2.demo.service;

import softuni.lection2.demo.model.view.OfferSummaryViewModel;

import java.util.List;

public interface OfferService {
    List<OfferSummaryViewModel> getAllOffers();
}
