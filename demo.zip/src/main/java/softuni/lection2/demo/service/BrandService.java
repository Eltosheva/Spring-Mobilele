package softuni.lection2.demo.service;

import softuni.lection2.demo.model.view.BrandViewModel;

import java.util.List;


public interface BrandService {
    List<BrandViewModel> getAllBrands();
}
