package softuni.lection2.demo.service.impl;

import org.springframework.stereotype.Service;
import softuni.lection2.demo.model.view.OfferSummaryViewModel;
import softuni.lection2.demo.service.OfferService;

import java.util.List;

@Service
public class OfferServiceImpl implements OfferService {

    @Override
    public List<OfferSummaryViewModel> getAllOffers() {

        //TODO - implement mapping
        throw new UnsupportedOperationException("Comming soon :-)))");
    }
}
