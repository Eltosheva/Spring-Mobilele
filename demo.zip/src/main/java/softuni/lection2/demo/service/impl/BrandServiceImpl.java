package softuni.lection2.demo.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.lection2.demo.model.entities.BrandEntity;
import softuni.lection2.demo.model.entities.ModelEntity;
import softuni.lection2.demo.model.view.ModelViewModel;
import softuni.lection2.demo.repository.ModelRepository;
import softuni.lection2.demo.service.BrandService;
import softuni.lection2.demo.model.view.BrandViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BrandServiceImpl implements BrandService {

    private final ModelRepository modelRepository;
    private final ModelMapper modelMapper;

    public BrandServiceImpl(ModelRepository modelRepository, ModelMapper modelMapper) {
        this.modelRepository = modelRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<BrandViewModel> getAllBrands() {
        List<BrandViewModel> result = new ArrayList<>();//<- final result here
        List<ModelEntity> allModels = modelRepository.findAll();

        allModels.forEach(me -> {
            //example : fiesta - ford
            BrandEntity brandEntity = me.getBrand();
            Optional<BrandViewModel> brandViewModelOpt = findByName(result, brandEntity.getName());
            if (!brandViewModelOpt.isPresent()) {
                //not yet in result , we will creat a new model
                BrandViewModel newBrandViewModel = new BrandViewModel();
                modelMapper.map(brandEntity, newBrandViewModel);
                result.add(newBrandViewModel);
                brandViewModelOpt = Optional.of(newBrandViewModel);
            }

            ModelViewModel newModelViewMdel = new ModelViewModel();
            modelMapper.map(me, newModelViewMdel);
            brandViewModelOpt.get().addModel(newModelViewMdel);
        });

        return result;
    }

    private static Optional<BrandViewModel> findByName(List<BrandViewModel> allModels, String name) {
        return allModels
                .stream()
                .filter(m -> m.getName().equals(name))
                .findAny();
    }
}
