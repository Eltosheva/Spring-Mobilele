package softuni.lection2.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import softuni.lection2.demo.model.entities.*;
import softuni.lection2.demo.model.entities.enums.EngineEnum;
import softuni.lection2.demo.model.entities.enums.ModelCategory;
import softuni.lection2.demo.model.entities.enums.TransmissionEnum;
import softuni.lection2.demo.repository.BrandRepository;
import softuni.lection2.demo.repository.ModelRepository;
import softuni.lection2.demo.repository.OfferRepository;
import softuni.lection2.demo.repository.UserRepository;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@Component
public class DBInit implements CommandLineRunner {
    private final ModelRepository modelRepository;
    private final BrandRepository brandRepository;
    private final OfferRepository offerRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;

    public DBInit(BrandRepository brandRepository,
                  ModelRepository modelRepository,
                  OfferRepository offerRepository,
                  PasswordEncoder passwordEncoder,
                  UserRepository userRepository) {
        this.brandRepository = brandRepository;
        this.modelRepository = modelRepository;
        this.offerRepository = offerRepository;
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        BrandEntity fordBrand = new BrandEntity();
        fordBrand.setName("Ford");
        setCurrentTimestams(fordBrand);

        BrandEntity hondaBrand = new BrandEntity();
        hondaBrand.setName("Honda");
        setCurrentTimestams(hondaBrand);

        brandRepository.saveAll(List.of(fordBrand, hondaBrand));

        ModelEntity fiestaModel = initFiesta(fordBrand);
        initEscort(fordBrand);
        initHornet(hondaBrand);
        creatFiestaOffer(fiestaModel);

        initAdmin();
    }

    private void initAdmin() {
        UserEntity admin = new UserEntity();
        admin.setFirstName("Петър")
                .setLastName("Димитров")
                .setUsername("admin")
                .setPassword(passwordEncoder.encode("topsecret"));

        setCurrentTimestams(admin);

        userRepository.save(admin);
    }

    private void creatFiestaOffer(ModelEntity modelEntity) {
        OfferEntity fiestaOffer = new OfferEntity();
        fiestaOffer.setEngine(EngineEnum.GASOLINE)
                .setImageUrl("https://www.motopfohe.bg/files/news/archive/2017/08/blob-server2.jpg")
                .setMileage(80000)
                .setPrice(BigDecimal.valueOf(10000))
                .setYear(2017)
                .setDescription("Karana e ot nemska baba. Zimata v garaj.")
                .setTransmission(TransmissionEnum.MANUAL)
                .setModel(modelEntity);
        setCurrentTimestams(fiestaOffer);
        offerRepository.save(fiestaOffer);
    }

    private ModelEntity initHornet(BrandEntity hondaBrand) {
        ModelEntity hornet = new ModelEntity();
        hornet
                .setName("Hornet")
                .setCategory(ModelCategory.MOTORCYCLE)
                .setImageUrl("https://i.pinimg.com/originals/60/b3/89/60b3894a7d2eca2a9345ed4f49dfef21.jpg")
                .setStartYear(1998)
                .setEndYear(2013)
                .setBrand(hondaBrand);

        setCurrentTimestams(hornet);

        return modelRepository.save(hornet);
    }

    private ModelEntity initEscort(BrandEntity fordBrand) {
        ModelEntity escort = new ModelEntity();
        escort
                .setName("Escort")
                .setCategory(ModelCategory.CAR)
                .setImageUrl("https://www.nastarta.com/wp-content/uploads/2017/10/ken-blocks-1991-ford-escort-cosworth-rally-car.jpg")
                .setStartYear(1968)
                .setEndYear(2002)
                .setBrand(fordBrand);

        setCurrentTimestams(escort);

        return modelRepository.save(escort);
    }

    private ModelEntity initFiesta(BrandEntity fordBrand) {
        ModelEntity fiesta = new ModelEntity();
        fiesta
                .setName("Fiesta")
                .setCategory(ModelCategory.CAR)
                .setImageUrl("https://images.autowereld.com/1600x1000/154111-2018fordfiesta-magnetic-st-02.jpg")
                .setStartYear(1976)
                .setBrand(fordBrand);

        setCurrentTimestams(fiesta);

        return modelRepository.save(fiesta);
    }

    private static void setCurrentTimestams(BaseEntity baseEntity) {
        baseEntity.setCreated(Instant.now());
        baseEntity.setUpdated(Instant.now());
    }
}
