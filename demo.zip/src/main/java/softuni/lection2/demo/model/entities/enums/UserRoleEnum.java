package softuni.lection2.demo.model.entities.enums;

public enum UserRoleEnum {
    ADMIN,
    USER,
}
