package softuni.lection2.demo.model.entities.enums;

public enum EngineEnum {
    GASOLINE,
    DIESEL,
    ELECTRIC,
    HYBRID
}
