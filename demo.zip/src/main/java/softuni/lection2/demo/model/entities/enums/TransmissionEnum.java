package softuni.lection2.demo.model.entities.enums;

public enum TransmissionEnum {
    MANUAL,
    AUTOMATIC
}
