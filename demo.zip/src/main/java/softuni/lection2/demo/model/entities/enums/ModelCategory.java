package softuni.lection2.demo.model.entities.enums;

public enum ModelCategory {
    CAR,
    BUS,
    TRUCK,
    MOTORCYCLE
}
