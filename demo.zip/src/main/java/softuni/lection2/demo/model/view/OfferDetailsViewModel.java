package softuni.lection2.demo.model.view;

public class OfferDetailsViewModel extends OfferSummaryViewModel{

}
